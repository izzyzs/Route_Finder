namespace API.Services;

public interface IGTFSService
{
    Task t();
}

public class GTFSService
{
    
}