
using System.Diagnostics;
using API.Data;
using API.Services;
using GeoCoordinatePortable;

namespace API.Models;

public class DestinationRoute
{
    private ILocationService _locationService;
    private GTFSDbContext _context;

    private (GeoCoordinate, GeoCoordinate) startAndEnd;
    private string scheduleServiceId;
    public List<Leg> _legs = new List<Leg>();

    public DestinationRoute(ILocationService locationService, GTFSDbContext context, double startLat, double startLon, double endLat, double endLon, string date)
    {
        _locationService = locationService;
        _context = context;
        GeoCoordinate start = new GeoCoordinate(startLat, startLon);
        GeoCoordinate end = new GeoCoordinate(endLat, endLon);
        startAndEnd = (start, end);
        DateTime d = DateTime.Parse(date);
        scheduleServiceId = CalendarGTFS.getServiceID(d.DayOfWeek, _context).ServiceID ?? "Weekday";
    }

    public void addLeg(Leg leg)
    {
        _legs.Add(leg);
    }


    public async Task<(List<string>, List<string>)> FindClosestStops()
    {
        var locations = await _locationService.GetLocationsAsync();

        GeoCoordinate myLocation = startAndEnd.Item1;
        GeoCoordinate endLocation = startAndEnd.Item2;

        List<string> startStopIDs = locations
                        .Where(l => l.Coordinate.GetDistanceTo(myLocation) <= 600)
                        .GroupBy(l => l.Stop.StopID.Substring(0, 3))
                        .Select(g => g.First().Stop.StopID).ToList();
        List<string> endStopIDs = locations
                        .Where(l => l.Coordinate.GetDistanceTo(myLocation) <= 600)
                        .GroupBy(l => l.Stop.StopID.Substring(0, 3))
                        .Select(g => g.First().Stop.StopID).ToList();


        return (startStopIDs, endStopIDs);
    }

    public List<Leg> ConnectRoutes(List<string> startStops, List<string> endStops) {
        
    }

}

/******
*
*

DestinationRoute
(GEOLOCATION, GEOLOCATION) data
@params List<Leg> Legs
******/