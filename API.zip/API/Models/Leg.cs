namespace API.Models;

public class Leg // start_time, end_time, start_stop_id, end_stop_id
{
    
}